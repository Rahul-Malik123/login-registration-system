# Password Manager

This is a secure password management system based on Python. Although the system is relatively secure, I am by no means a security professional so I would be careful when using this is production software.

*This project is designed as a proof of concept. I would be careful when using this in high-security environments.
